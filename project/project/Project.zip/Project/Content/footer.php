<div class="footer" >
            <div class="info">
                <p>CONTACT US: <a href="mailto:contact_us@qub.uk.com">contact_us@qub.uk.com</a></p>
                <p>Phone: +44 01234567</p>
                <p><Address>University Rd, Belfast, UK - BT7 1NN</Address></p>
                <div class="share">
                    <i class='bx bxl-facebook' ></i>
                    <i class='bx bxl-instagram-alt' ></i>
                    <i class='bx bxl-twitter' ></i>
                    <i class='bx bxl-youtube' ></i>
                    <i class='bx bxl-snapchat' ></i>
                    <i class='bx bxl-tiktok' ></i>
                </div>
            </div>
            <div class="word">
                <p>Hope all people to have equal access to education</p>
                <p>Guided by the United Nations</p>
                <p>Sustainable Development Goal 4</p>
                <p>SDG4: Quantity Education</p>
            </div>
            <div class="icon_f" >
                <img src="image12.png" />
            </div>
        </div>
        <div class="mobile-footer" >
            <div class="word">
                <p>Hope all people to have equal access to education</p>
                <p>Guided by the United Nations Sustainable Development Goal 4</p>
            </div>
            <div class="footer-bottom">
                <div class="info">
                    <p class="info-contact">CONTACT US: <a href="mailto:contact_us@qub.uk.com">contact_us@qub.uk.com</a></p>
                    <p>Phone: +44 01234567</p>
                    <p><Address>University Rd, Belfast, UK - BT7 1NN</Address></p>
                    <div class="share">
                        <i class='bx bxl-facebook' ></i>
                        <i class='bx bxl-instagram-alt' ></i>
                        <i class='bx bxl-twitter' ></i>
                        <i class='bx bxl-youtube' ></i>
                        <i class='bx bxl-snapchat' ></i>
                        <i class='bx bxl-tiktok' ></i>
                    </div>
                </div>
                <div class="icon_f" >
                    <img src="image12.png" />
                </div>
            </div>