<?php

?>
<section class="footer">

<div class="box-container">

    <div class="box">
        <h3> </h3>
        <p class="links">genre picture from Pexels.com</p>
        <p class="links">Icons made by Freepik from www.flaticon.com</p>
    </div>

    <div class="box">
        <h3>Welcome to contact us</h3>
        <p> <i class="fas fa-phone"></i> +028-9024-5133 </p>
        <p> <i class="fas fa-envelope"></i> mxiao02@gmail.com </p>
        <p> <i class="fas fa-map"></i> University Rd, Belfast, UK - BT7 1NN </p>
        <div class="share">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
            <a href="#" class="fab fa-linkedin"></a>
            <a href="#" class="fab fa-pinterest"></a>
        </div>
    </div>
</div>

</section>

<div class="credit"><span>mr. web designer</span> | all rights reserved! </div>